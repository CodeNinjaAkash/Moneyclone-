# MoneyClone build guide
1. Install Android Studio (Koala or newer). File > Open > select the MoneyClone folder. Let Gradle sync.
2. Plug in your iQOO Z9s Pro (USB debugging on) and press Run, or Build > Build APK(s).
3. Open MoneyClone > Dashboard > "Set up clone space" (creates the work profile).
4. Install MoneyClone also inside the work profile (briefcase) if prompted, open that copy, then Apps tab > tap an app to clone.
5. Settings tab: do steps 1-3 buttons, then switch on Auto-start.
6. iQOO: also long-press MoneyClone > App info > Battery > Unrestricted, and lock it in the Recents screen.
