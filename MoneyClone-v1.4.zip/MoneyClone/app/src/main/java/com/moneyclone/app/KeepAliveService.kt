package com.moneyclone.app
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings

class KeepAliveService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var n = 0
    private val tick = object : Runnable {
        override fun run() { n++; notif("Keeping ${Prefs.clones(this@KeepAliveService).size} clones alive (check #$n)"); h.postDelayed(this, 5 * 60_000L) }
    }
    private fun notif(t: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ka", "MoneyClone", NotificationManager.IMPORTANCE_LOW))
        val nt = Notification.Builder(this, "ka").setContentTitle("MoneyClone running").setContentText(t)
            .setSmallIcon(android.R.drawable.ic_popup_sync).setOngoing(true).build()
        startForeground(1, nt, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
    }
    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        notif("Starting…"); h.removeCallbacks(tick); h.post(tick)
        // Needs "Display over other apps" so Android allows launching from background.
        if (i?.getBooleanExtra("launch", false) == true && Settings.canDrawOverlays(this))
            Prefs.clones(this).filter { Prefs.bool(this, "as_" + it.pkg, true) }.forEachIndexed { n2, c -> h.postDelayed({ WorkProfileEngine.open(this, c.pkg) }, n2 * 1500L) }
        return START_STICKY
    }
    override fun onDestroy() { h.removeCallbacks(tick) }
    override fun onBind(i: Intent?): IBinder? = null
    companion object {
        fun start(c: Context, launch: Boolean) = c.startForegroundService(Intent(c, KeepAliveService::class.java).putExtra("launch", launch))
        fun stop(c: Context) = c.stopService(Intent(c, KeepAliveService::class.java))
    }
}
