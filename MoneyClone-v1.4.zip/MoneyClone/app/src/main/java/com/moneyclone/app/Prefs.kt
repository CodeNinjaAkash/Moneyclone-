package com.moneyclone.app
import android.content.Context

data class Clone(val pkg: String, val name: String)

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("mc", 0)
    fun clones(c: Context): List<Clone> = WorkProfileEngine.list(c).map { Clone(it.first, sp(c).getString("n_" + it.first, null) ?: (it.second + " clone")) }
    fun add(c: Context, cl: Clone) {}   // clones are now read from the work profile itself
    fun remove(c: Context, pkg: String) = sp(c).edit().remove("n_" + pkg).apply()
    fun rename(c: Context, pkg: String, n: String) = sp(c).edit().putString("n_" + pkg, n).apply()
    fun bool(c: Context, k: String, d: Boolean = false) = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
    fun int(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
}
