package com.moneyclone.app
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.fragment.app.FragmentActivity

class MainActivity : FragmentActivity() {
    private var unlocked by mutableStateOf(false)
    private val eng: CloneEngine = WorkProfileEngine

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        intent.getStringExtra("launch_pkg")?.let { eng.open(this, it); finish(); return }
        if (Prefs.bool(this, "lock")) askFinger() else unlocked = true
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface(Modifier.fillMaxSize()) {
            if (unlocked) Home() else Box(Modifier.fillMaxSize()) { Button({ askFinger() }, Modifier.padding(32.dp)) { Text("Unlock MoneyClone") } }
        } } }
    }

    private fun askFinger() {
        val p = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) { unlocked = true }
        })
        p.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("MoneyClone").setNegativeButtonText("Cancel").build())
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun Home() {
        var tab by remember { mutableStateOf(0) }
        var clones by remember { mutableStateOf(Prefs.clones(this)) }
        val apps = remember { packageManager.getInstalledApplications(0).filter { packageManager.getLaunchIntentForPackage(it.packageName) != null && it.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() } }
        var auto by remember { mutableStateOf(Prefs.bool(this, "auto")) }
        var lock by remember { mutableStateOf(Prefs.bool(this, "lock")) }
        var rename by remember { mutableStateOf<Clone?>(null) }
        val pm = getSystemService(PowerManager::class.java)

        Column(Modifier.fillMaxSize()) {
            TopAppBar(title = { Text("MoneyClone Premium") })
            TabRow(tab) { listOf("Dashboard", "Apps", "Clones", "Settings").forEachIndexed { i, t -> Tab(tab == i, { tab = i }) { Text(t, Modifier.padding(12.dp)) } } }
            when (tab) {
                0 -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Clones: ${clones.size}")
                    Text("Clone space: ${if (eng.ready(this@MainActivity)) "ready" else "not set up"}")
                    Text("Battery unrestricted: ${pm.isIgnoringBatteryOptimizations(packageName)}")
                    Text("Overlay (background launch): ${Settings.canDrawOverlays(this@MainActivity)}")
                    Text("Auto-start: $auto   App lock: $lock")
                    if (!eng.ready(this@MainActivity)) Button({ eng.setup(this@MainActivity) }) { Text("Set up clone space") }
                }
                1 -> LazyColumn { items(apps) { a ->
                    val label = a.loadLabel(packageManager).toString()
                    ListItem(headlineContent = { Text(label) }, supportingContent = { Text(a.packageName) },
                        modifier = Modifier.clickable {
                            val r = eng.create(this@MainActivity, a.packageName)
                            if (r == "Cloned") { Prefs.add(this@MainActivity, Clone(a.packageName, "$label clone")); clones = Prefs.clones(this@MainActivity) }
                            toast(r)
                        })
                } }
                2 -> LazyColumn { items(clones) { c ->
                    ListItem(headlineContent = { Text(c.name) }, supportingContent = { Text(c.pkg) }, trailingContent = {
                        Row {
                            TextButton({ eng.open(this@MainActivity, c.pkg) }) { Text("Open") }
                            TextButton({ rename = c }) { Text("Edit") }
                            TextButton({ eng.delete(this@MainActivity, c.pkg); Prefs.remove(this@MainActivity, c.pkg); clones = Prefs.clones(this@MainActivity) }) { Text("Del") }
                        }
                    })
                } }
                3 -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row { Text("Auto-start all clones", Modifier.weight(1f)); Switch(auto, { auto = it; Prefs.setBool(this@MainActivity, "auto", it)
                        if (it) KeepAliveService.start(this@MainActivity, false) else KeepAliveService.stop(this@MainActivity) }) }
                    Row { Text("Fingerprint app lock", Modifier.weight(1f)); Switch(lock, { lock = it; Prefs.setBool(this@MainActivity, "lock", it) }) }
                    Button({ startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }) { Text("1. Allow unrestricted battery") }
                    Button({ startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }) { Text("2. Allow display over other apps") }
                    Button({ startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }) { Text("3. App info → enable Autostart") }
                    Button({ clones.forEach { c -> ShortcutManagerCompat.requestPinShortcut(this@MainActivity, ShortcutInfoCompat.Builder(this@MainActivity, c.pkg)
                        .setShortLabel(c.name).setIcon(IconCompat.createWithResource(this@MainActivity, android.R.drawable.sym_def_app_icon))
                        .setIntent(Intent(this@MainActivity, MainActivity::class.java).setAction(Intent.ACTION_MAIN).putExtra("launch_pkg", c.pkg)).build(), null) } }) { Text("Add clone shortcuts to home") }
                }
            }
        }
        rename?.let { c ->
            var t by remember { mutableStateOf(c.name) }
            AlertDialog(onDismissRequest = { rename = null }, title = { Text("Rename clone") },
                text = { OutlinedTextField(t, { t = it }) },
                confirmButton = { TextButton({ Prefs.rename(this@MainActivity, c.pkg, t); clones = Prefs.clones(this@MainActivity); rename = null }) { Text("Save") } })
        }
    }
}
