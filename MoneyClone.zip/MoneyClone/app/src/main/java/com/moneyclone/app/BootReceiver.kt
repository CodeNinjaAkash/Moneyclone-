package com.moneyclone.app
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Prefs.bool(c, "auto")) KeepAliveService.start(c, true)
    }
}
